/*----------------------------------------
  wholebrain Package initialization 
  Copyright (c) 2016 Daniel Fürth
  See ../LICENSE for LPGL License Text
  ----------------------------------------*/



// R
#include <Rcpp.h>

//  event loop
extern int (*R_timeout_handler)();
extern long R_timeout_val;

