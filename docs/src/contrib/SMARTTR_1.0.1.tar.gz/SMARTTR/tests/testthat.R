library(testthat)
library(SMARTTR)

test_check("SMARTTR")
