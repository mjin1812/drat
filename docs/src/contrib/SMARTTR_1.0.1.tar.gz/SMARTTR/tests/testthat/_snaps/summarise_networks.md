# summarizing networks works

    Code
      e$networks_summaries$eyfp$networks_stats
    Output
      # A tibble: 2 x 22
        group degree.mean triangles.mean clust.coef.mean avg.dist.mean efficiency.mean
        <fct>       <dbl>          <dbl>           <dbl>         <dbl>           <dbl>
      1 Cont~        2.95           3.65           0.334          2.18           0.142
      2 Shock        2.26           1.73           0.208          1.21           0.104
      # i 16 more variables: btw.mean <dbl>, degree.sd <dbl>, triangles.sd <dbl>,
      #   clust.coef.sd <dbl>, avg.dist.sd <dbl>, efficiency.sd <dbl>, btw.sd <dbl>,
      #   degree.sem <dbl>, triangles.sem <dbl>, clust.coef.sem <dbl>,
      #   avg.dist.sem <dbl>, efficiency.sem <dbl>, btw.sem <dbl>, n.nodes <int>,
      #   n.edges <int>, edge.density <dbl>

